﻿namespace AlphaScan
{
    class GPSUtil
    {
    }
}
