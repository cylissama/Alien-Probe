﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlphaScanCam.Entities
{
   public abstract class CameraInterface
    {

    }
}
