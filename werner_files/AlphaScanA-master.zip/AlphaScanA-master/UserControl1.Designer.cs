﻿<?xml version="1.0" encoding="utf-8"?>
<LotCount LotName="Poland" Zone="H4" StartTime="2020-09-23T10:24:40.2127644-05:00" EndTime="2020-09-23T10:38:58.3006315-05:00">
  <Prefix name="20H4">1</Prefix>
  <Prefix name="20HU">1</Prefix>
  <Prefix name="20H6">1</Prefix>
  <Prefix name="20H9">1</Prefix>
</LotCount>