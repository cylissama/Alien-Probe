﻿ReadMe

Note:
In comments throughout the code, we use a few tags to signify where more work can be done. You can search these tags with Ctrl+F.
"$$" signifies that there is something that we can/should improve.
"$?" or "$$?" signifies that there may be something that we can improve.
"$$$" (or more dollar signs) is usually placed near commented out code or lines added for debugging. Should be removed in the final version.

Contact Info:
Here is a list of people who worked on the code, with contact information for the purpose of clarifying any issues that come up.
Terrance Life - Project lead. Combination code, GUI. - terrance.life056@topper.wku.edu
Murphey Kilgore - Worked on mmWave, GPS code - murpheykilgore@gmail.com
Samuel Everson - Worked on RFID, architecture, threading - sameverson@live.com
Landon Owens - Worked on GUI - landon.owens017@topper.wku.edu

